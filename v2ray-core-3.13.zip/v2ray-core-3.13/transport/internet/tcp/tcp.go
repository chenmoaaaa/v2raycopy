package tcp

//go:generate go run $GOPATH/src/v2ray.com/core/common/errors/errorgen/main.go -pkg tcp -path Transport,Internet,TCP
