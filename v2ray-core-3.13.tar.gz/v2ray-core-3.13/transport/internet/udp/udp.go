package udp

//go:generate go run $GOPATH/src/v2ray.com/core/common/errors/errorgen/main.go -pkg udp -path Transport,Internet,UDP
