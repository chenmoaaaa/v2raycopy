package core

//go:generate go get -u "github.com/golang/protobuf/protoc-gen-go"
//go:generate go get -u "github.com/golang/protobuf/proto"
//go:generate go install "v2ray.com/ext/tools/vprotogen"
//go:generate vprotogen -repo v2ray.com/core
